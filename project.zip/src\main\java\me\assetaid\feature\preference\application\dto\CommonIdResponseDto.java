package me.assetaid.feature.preference.application.dto;

// 단순히 ID를 전달하는 용도로 사용
public record CommonIdResponseDto(int preferenceId) {
}
