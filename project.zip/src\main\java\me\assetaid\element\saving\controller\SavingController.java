package me.assetaid.element.saving.controller;

public class SavingController {
}
